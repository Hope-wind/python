import scrapy,requests
from random import randint
from dimensional.items import DimensionalItem


class MainSpider(scrapy.Spider):
    name = 'main'
    allowed_domains = ['anime-pictures.net']
    start_urls = ['https://anime-pictures.net/pictures/view_posts/{}?lang=en'.format(page) for page in range(0,8000+1)]

    def parse(self, response):
        result_list = response.xpath('//span[@class="img_block_big"]')
        for sel in result_list:
            image_url = sel.xpath('./a/picture/source/img/@src').extract_first()
            img_url = 'https:' + image_url  # 手动拼url
            id = str(randint(0, 99999999999999))
            file_name = id + '.' + img_url.split('.')[-1]
            content = requests.get(url=img_url).content
            item = DimensionalItem(content = content,file_name = file_name)

            yield item
