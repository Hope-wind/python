import scrapy
from random import randint
import requests,os
from ..items import DimensionalItem

path = os.path.dirname(__file__)
path = path + '\\image\\'
if not os.path.exists(path):
    print('检测到没有容器')
    os.mkdir(path)
    print('生成完毕' + path)




class MainSpider(scrapy.Spider):
    name = 'main'
    allowed_domains = ['anime-pictures.net']
    start_urls = ['https://anime-pictures.net/pictures/view_posts/1?lang=en']

    def parse(self, response):
        result_list = response.xpath('//span[@class="img_block_big"]')
        for sel in result_list:
            image_url = sel.xpath('./a/picture/source/img/@src').extract_first()
            img_url = 'https:' + image_url  # 手动拼url
            id = str(randint(0, 99999999999999))
            content = requests.get(url = img_url).content
            file_name = id + '.' + img_url.split('.')[-1]

            try:
                with open(path + file_name ,mode = 'wb') as f:
                    f.write(content)
                    print("保存完成:",id)
            except Exception as e:
                print(e)
