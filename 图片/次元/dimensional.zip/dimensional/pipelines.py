from itemadapter import ItemAdapter
import os,scrapy
path = os.path.dirname(__file__)
path = path + '\\image\\'
if not os.path.exists(path):
    print('检测到没有容器')
    os.mkdir(path)
    print('生成完毕' + path)


class DimensionalPipeline:
    def process_item(self, item, spider):
        content = item['content']
        file_name = item['file_name']
        try:
            with open(path + file_name,mode = 'wb') as f:
                f.write(content)
                print('保存完成:',file_name)


        except Exception as e:
            print(e)



        return item
